﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfAppTCS_2341269
{
    public static class SD
    {
        public static string APIBaseUrl = "https://gorest.co.in/public-api/";
        public static string EmployeeListAPI = APIBaseUrl + "users";
        public static string EmployeeAPI = APIBaseUrl + "users/";
        public static string token = "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56";
       
    }
}
