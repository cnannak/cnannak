﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfAppTCS_2341269.ViewModels
{
    public class EmployeeViewModel
    {
        
    }
}
